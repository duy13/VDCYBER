#!/bin/bash
# chmod 700 /cyber-control/backup-restore.sh
# /cyber-control/backup-restore.sh

yourchoice=''
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1
clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'


tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}############################ ${yellow}CYBERPANEL CONTROL${red} ###########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}voduy.com${red} ################################${no}"
echo ""
echo ' HOME | Backup/Restore
'
echo "Please select the following function:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. Create Backup File
 2. Restore Backup File


 0. Back

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2... or 0]: " 
read yourchoice


mkdir -p /backup
clear
# 1. Create Backup
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
if [ "$yourchoice" = "1" ]; then
echo -n "
Enter your Domain Name to Create Backup File [Ex: domain.com]: " 
read yourdomain

Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi

# Create Backup
/usr/bin/cyberpanel createBackup --domainName $yourdomain

clear; dirnow=`pwd`; cd /home/$yourdomain/backup/ ; backupname=`ls *.tar.gz` ; cd $dirnow

mv /home/$yourdomain/backup/*.tar.gz /backup
backupsize=`du -sh /backup/*.tar.gz`
backupname=`echo "$backupname"`
backupsize=`echo "$backupsize"`
sleep 2
clear
echo ' Successfully! Your '$yourdomain' Backup File is as follows, please Download:
'
echo "$backupname"
echo "$backupsize"

echo ' Successfully! Your '$yourdomain' Backup File is as follows, please Download:
' >> /cyber-control/log.txt
echo "$backupname" >> /cyber-control/log.txt
echo "$backupsize" >> /cyber-control/log.txt

echo -n "Press Enter to Back: " 
read Enter
/cyber-control/backup-restore.sh

fi




# 2. Restore Backup
if [ "$yourchoice" = "2" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to Restore Backup [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi

echo -n '
Are you sure ALL DATA in "'$yourdomain'" will be REMOVE [Ex: y/N]: ' 
read yoursure
if  [ "$yoursure" != "y" ]; then
echo 'Ok! Exit...'
exit 0
fi

sleep 2
clear 
dirnow=`pwd`; cd /backup/; du -sh * ; cd $dirnow

echo -n "
Enter your Backup File Name to Restore [Ex: domain.tar.gz]: " 
read yourbackupfilename

if [ ! -f /backup/$yourbackupfilename ] || [ "$yourbackupfilename" = "" ]; then
echo 'Please upload Backup File '$yourbackupfilename' to folder /backup'
exit 0
fi

echo ' Start REMOVE DATA of '$yourdomain' and RESTORE '$yourbackupfilename', 
If you want to stop, press Ctrl + C right now! 
You have 10 seconds countdown ...'
sleep 10

clear
echo 'Start REMOVE DATA of '$yourdomain'...'
sleep 5
/usr/bin/cyberpanel deleteWebsite --domainName $yourdomain >/dev/null 2>&1

echo 'Successfully REMOVE DATA of '$yourdomain'!'
echo 'Start RESTORE DATA of '$yourbackupfilename' to '$yourdomain'...'
dirnow=`pwd`; cd /backup 
/usr/bin/cyberpanel restoreBackup --fileName $yourbackupfilename >/dev/null 2>&1
cd $dirnow

echo 'Successfully RESTORE DATA of '$yourbackupfilename' to '$yourdomain'!'

echo -n '
Press Enter to Back: '
read Enter
/cyber-control/backup-restore.sh
exit 0
fi





if [ "$yourchoice" = "0" ] || [ "$yourchoice" = "" ]; then
echo 'Back!'
sleep 1
/cyber-control/home.sh
exit 0
fi

exit 0
