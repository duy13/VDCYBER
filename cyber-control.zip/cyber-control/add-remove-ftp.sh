#!/bin/bash
# chmod 700 /cyber-control/add-remove-ftp.sh
# /cyber-control/add-remove-ftp.sh

yourchoice=''
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1
clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'


tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}############################ ${yellow}CYBERPANEL CONTROL${red} ###########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}voduy.com${red} ################################${no}"
echo ""
echo ' HOME | FTP
'
echo "Please select the following function:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. Add User FTP
 2. List User FTP
 3. Remove User FTP
 4. Change Password User FTP


 0. Back

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2, 3... or 0]: " 
read yourchoice



clear
# 1. Add FTP
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
if [ "$yourchoice" = "1" ]; then
echo -n "
Enter your Domain Name to Add FTP User [Ex: domain.com]: " 
read yourdomain

Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi

# Add FTP
yourserverip=`curl -4 --silent icanhazip.com`
yourftpuser=`echo "FTP$(cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 7)"`
yourftppass=`cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 13`
/usr/bin/cyberpanel createFTPAccount --domainName $yourdomain --userName $yourftpuser --password $yourftppass --owner admin


sleep 2
clear
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

FTP SERVER: '$yourserverip' port 21
FTP USER:   '$yourftpuser'
FTP PASS:   '$yourftppass'

'
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

FTP SERVER: '$yourserverip' port 21
FTP USER:   '$yourftpuser'
FTP PASS:   '$yourftppass'

' >> /cyber-control/log.txt


echo -n "Press Enter to Back: " 
read Enter
/cyber-control/add-remove-ftp.sh

fi



# 2. List FTP
if [ "$yourchoice" = "2" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to List FTP [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following are FTP in "'$yourdomain'":
'
/usr/bin/cyberpanel listFTPPretty --domainName $yourdomain
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/add-remove-ftp.sh

fi




# 3. Remove FTP
if [ "$yourchoice" = "3" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to List FTP User [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following are FTP in "'$yourdomain'":
'
/usr/bin/cyberpanel listFTPPretty --domainName $yourdomain
echo -n "
Enter your FTP User to Remove [Ex: FTP0wQRMmy]: " 
read yourftpuser
if  [ "$yourftpuser" = "" ]; then
echo 'Error! Please select again...'
exit 0
fi
/usr/bin/cyberpanel deleteFTPAccount --userName $yourftpuser  >/dev/null 2>&1

echo -n '
Successfully remove "'$yourftpuser'"! Press Enter to Back: '
read Enter
/cyber-control/add-remove-ftp.sh
exit 0
fi







# 4. Change Password User FTP
if [ "$yourchoice" = "4" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to Remove FTP User [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following is FTP User in "'$yourdomain'":
'
/usr/bin/cyberpanel listFTPPretty --domainName $yourdomain
echo -n "
Enter your FTP User to Change Password [Ex: FTP0wQRMmy]: " 
read yourftpuser
if  [ "$yourftpuser" = "" ]; then
echo 'Error! Please select again...'
exit 0
fi
yourftppass=`cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 13`
yourserverip=`curl --silent -L http://cpanel.net/showip.cgi`
/usr/bin/cyberpanel changeFTPPassword --userName $yourftpuser --password $yourftppass

sleep 2
clear
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

FTP SERVER: '$yourserverip' port 21
FTP User:   '$yourftpuser'
FTP PASS:   '$yourftppass'

'
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

FTP SERVER: '$yourserverip' port 21
FTP User:   '$yourftpuser'
FTP PASS:   '$yourftppass'

'  /cyber-control/log.txt


echo -n '
Successfully Change Password "'$yourftpuser'"! Press Enter to Back: '
read Enter
/cyber-control/add-remove-ftp.sh
exit 0
fi












if [ "$yourchoice" = "0" ] || [ "$yourchoice" = "" ]; then
echo 'Back!'
sleep 1
/cyber-control/home.sh
exit 0
fi

exit 0
