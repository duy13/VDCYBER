#!/bin/bash
# ln -s /cyber-control/home.sh /usr/bin/cyber-control
# chmod 700 /cyber-control/*.sh
# /usr/bin/cyber-control
yourchoice=''
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1
clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'


tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}############################ ${yellow}CYBERPANEL CONTROL${red} ###########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}voduy.com${red} ################################${no}"
echo ""
echo ' HOME |
'
echo "Please select the following function:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. Add/Remove Domain
 2. Add/Remove Database
 3. Add/Remove Email
 4. Add/Remove FTP
 5. Backup/Restore
 6. Update .htaccess
 7. Other


 0. Exit

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2, 3... or 0]: " 
read yourchoice




if [ "$yourchoice" = "1" ]; then
/cyber-control/add-remove-domain.sh
fi

if [ "$yourchoice" = "2" ]; then
/cyber-control/add-remove-database.sh
fi

if [ "$yourchoice" = "3" ]; then
/cyber-control/add-remove-email.sh
fi

if [ "$yourchoice" = "4" ]; then
/cyber-control/add-remove-ftp.sh
fi

if [ "$yourchoice" = "5" ]; then
/cyber-control/backup-restore.sh
fi


if [ "$yourchoice" = "6" ]; then
service lsws reload
echo -n 'Successfully update your .htaccess to OpenLiteSpeed! Press Enter to Back: '
read Enter
/cyber-control/home.sh
exit 0
fi

if [ "$yourchoice" = "7" ]; then
/cyber-control/other.sh
fi

if [ "$yourchoice" = "0" ]; then
echo 'Exit!'
exit 0
fi

exit 0
