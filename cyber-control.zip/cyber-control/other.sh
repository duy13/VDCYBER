#!/bin/bash
# ln -s /cyber-control/home.sh /usr/bin/cyber-control
# chmod 700 /cyber-control/home.sh
# /usr/bin/cyber-control
yourchoice=''
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1
clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'


tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}############################ ${yellow}CYBERPANEL CONTROL${red} ###########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}voduy.com${red} ################################${no}"
echo ""
echo ' HOME | Other
'
echo "Please select the following function:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. Fix permissions all public_html
 2. Fix all SSL websites
 3. Restart Web Server + Mysql Server
 4. Restart vDDOS
 5. Change PHP for website
 6. Update .htaccess


 0. Exit

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2, 3... or 0]: " 
read yourchoice




if [ "$yourchoice" = "1" ]; then
ran=`cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 5`
find /home/* -name public_html > tmppublic_html$ran.txt
ten_file_chua_list="tmppublic_html$ran.txt"
so_dong_file_chua_list=`cat $ten_file_chua_list | grep . | wc -l`
so_dong_bat_dau_tim=1
dong=$so_dong_bat_dau_tim
while [ $dong -le $so_dong_file_chua_list ]
do
ten=$(awk " NR == $dong " $ten_file_chua_list) ; echo "   Folder: $ten"
website=`echo $ten |  tr / " " | awk {'print $2'}` ; echo "   Website: $website"
user=`ls -lah /home/|grep $website | awk {'print $3'}` ; echo "   User: $user"
echo ' Starting: '$dong'. Fix permissions '$website'...'
sleep 1
#
chown -R $user:$user $ten
chmod -R 755 $ten
#


dong=$((dong + 1))
done
rm -f tmppublic_html$ran.txt
echo 'Successful: Fix permissions all public_html!'
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/other.sh
exit 0
fi

if [ "$yourchoice" = "2" ]; then
echo 'Starting Fix all SSL websites...'
sleep 2
/usr/bin/vddos-autoadd panel cyberpanel openlitespeed
/usr/bin/vddos-autoadd ssl-again
echo 'Successful: Fix all SSL websites!'
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/other.sh
exit 0
fi

if [ "$yourchoice" = "3" ]; then
echo 'Starting Restart Web Server + Mysql Server...'
service lsws restart
service mysql restart
service lscpd restart
echo 'Successful: Restart Web Server + Mysql Server!'
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/other.sh
exit 0
fi

if [ "$yourchoice" = "4" ]; then
echo 'Starting Restart vDDOS...'
/usr/bin/vddos restart
echo 'Successful: Restart vDDOS!'
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/other.sh
exit 0

fi

if [ "$yourchoice" = "5" ]; then

clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to Change PHP version [Ex: domain.com]: " 
read yourdomain

Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo -n "Enter your PHP version want to change [Ex: 5.6]: " 
read yourphpdomain
if  [ "$yourphpdomain" = "" ]; then
yourphpdomain="5.6"
fi

/usr/bin/cyberpanel changePHP --domainName cyberpanel.net --php $yourphpdomain  >/dev/null 2>&1

echo -n '
Successfully change PHP '$yourphpdomain' for '$yourdomain'! Press Enter to Back: '
read Enter
/cyber-control/other.sh
exit 0


fi

if [ "$yourchoice" = "6" ]; then
service lsws reload
echo -n 'Successfully update your .htaccess to OpenLiteSpeed! Press Enter to Back: '
read Enter
/cyber-control/other.sh
exit 0
fi


if [ "$yourchoice" = "0" ]; then
echo 'Exit!'
exit 0
fi

exit 0
