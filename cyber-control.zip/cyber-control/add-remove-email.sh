#!/bin/bash
# chmod 700 /cyber-control/add-remove-email.sh
# /cyber-control/add-remove-email.sh

yourchoice=''
PATH=/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin
source ~/.bashrc  >/dev/null 2>&1
source ~/.bash_profile  >/dev/null 2>&1
clear
# Chao mung:
red='\e[0;31m'
yellow='\e[1;33m'
no='\e[0m'
Background1='\e[41m\e[1;33m'


tput cup 1 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}WELCOME TO${red} ###############################${no}"
tput cup 2 $(($(tput cols)/2-38))
echo -e "${red}############################ ${yellow}CYBERPANEL CONTROL${red} ###########################${no}"
tput cup 3 $(($(tput cols)/2-38))
echo -e "${red}################################ ${yellow}voduy.com${red} ################################${no}"
echo ""
echo ' HOME | Mail
'
echo "Please select the following function:
$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)

 1. Add User Mail
 2. List User Mail
 3. Remove User Mail
 4. Change Password User Mail

 0. Back

$(for i in {16..29} {29..16} ; do echo -en "\e[38;5;${i}m__\e[0m" ; done ; echo)"
echo -n "Enter your choice [1, 2, 3... or 0]: " 
read yourchoice



clear
# 1. Add Email User
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
if [ "$yourchoice" = "1" ]; then
echo -n "
Enter your Domain Name to Add Mail User [Ex: domain.com]: " 
read yourdomain

Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo -n '
Enter your username to Add for "@'$yourdomain'" [Ex: admin]: '
read yourmailname
if  [ "$yourmailname" = "" ]; then
echo 'Error! Please select again...'
exit 0
fi
yourmailpass=`cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 7`
cyberpanel createEmail --domainName $yourdomain --userName $yourmailname --password $yourmailpass
yourserverip=`curl --silent -L http://cpanel.net/showip.cgi`



sleep 2
clear
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

MAIL SERVER: https://'$yourserverip':8090/rainloop/index.php
MAIL USER:   '$yourmailname'@'$yourdomain'
MAIL PASS:   '$yourmailpass'

'
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

MAIL SERVER: https://'$yourserverip':8090/rainloop/index.php
MAIL USER:   '$yourmailname'@'$yourdomain'
MAIL PASS:   '$yourmailpass'

' >> /cyber-control/log.txt


echo -n "Press Enter to Back: " 
read Enter
/cyber-control/add-remove-email.sh

fi



# 2. List Email User
if [ "$yourchoice" = "2" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to List Mail User [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following is Mail User in "'$yourdomain'":
'
/usr/bin/cyberpanel listEmailsPretty --domainName $yourdomain
echo -n "Press Enter to Back: " 
read Enter
/cyber-control/add-remove-email.sh

fi

# 3. Remove Email User
if [ "$yourchoice" = "3" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to Remove Mail User [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following is Mail User in "'$yourdomain'":
'
/usr/bin/cyberpanel listEmailsPretty --domainName $yourdomain

echo -n "
Enter your Mail User to Remove [Ex: admin@$yourdomain]: " 
read yourmailname
if  [ "$yourmailname" = "" ]; then
echo 'Error! Please select again...'
exit 0
fi
/usr/bin/cyberpanel deleteEmail --email $yourmailname

echo -n '
Successfully Remove "'$yourmailname'"! Press Enter to Back: '
read Enter
/cyber-control/add-remove-email.sh
exit 0
fi




# 4. Change Password User Mail
if [ "$yourchoice" = "4" ]; then
clear; dirnow=`pwd`; cd /home ; ls ; cd $dirnow
echo -n "
Enter your Domain Name to Remove Mail User [Ex: domain.com]: " 
read yourdomain
Websitestringcheck=`echo $yourdomain | grep -P '(?=^.{4,253}$)(^((?!-)[a-zA-Z0-9-]{1,63}(?<!-)\.)+[a-zA-Z]{2,63}$)'`
if  [ "$yourdomain" = "" ] || [ "$yourdomain" != "$Websitestringcheck" ]; then
echo 'Error! Please select again...'
exit 0
fi
echo '
The following is Mail User in "'$yourdomain'":
'
/usr/bin/cyberpanel listEmailsPretty --domainName $yourdomain
echo -n "
Enter your Mail User to Change Password [Ex: admin@$yourdomain]: " 
read yourmailname
if  [ "$yourmailname" = "" ]; then
echo 'Error! Please select again...'
exit 0
fi
yourmailpass=`cat /dev/urandom | tr -cd 'a-zA-Z0-9' | head -c 7`
yourserverip=`curl --silent -L http://cpanel.net/showip.cgi`
/usr/bin/cyberpanel changeEmailPassword --email $yourmailname --password $yourmailpass

sleep 2
clear
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

MAIL SERVER: https://'$yourserverip':8090/rainloop/index.php
MAIL USER:   '$yourmailname'
MAIL PASS:   '$yourmailpass'

'
echo ' Successfully! Your login information is as follows, please NOTE:

WEBSITE:             http://'$yourdomain'
WEBSITE HTTPS:       https://'$yourdomain'

MAIL SERVER: https://'$yourserverip':8090/rainloop/index.php
MAIL USER:   '$yourmailname'
MAIL PASS:   '$yourmailpass'

' >> /cyber-control/log.txt


echo -n '
Successfully Change Password "'$yourmailname'"! Press Enter to Back: '
read Enter
/cyber-control/add-remove-email.sh
exit 0
fi







if [ "$yourchoice" = "0" ] || [ "$yourchoice" = "" ]; then
echo 'Back!'
sleep 1
/cyber-control/home.sh
exit 0
fi

exit 0
